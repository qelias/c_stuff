To build the supporting libraries type

make
