#ifndef GNUPLOT_H
#define GNUPLOT_H

/* 
** A function to interface C with gnuplot.  The string is passed to gnuplot.
*/
int gnuplot(const char *); 

#endif
