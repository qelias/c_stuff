This file can be built into an executable by typing:

make

The executable can then be run by typing

./file_io.exe
