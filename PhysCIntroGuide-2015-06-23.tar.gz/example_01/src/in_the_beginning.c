/* W. H. Bell
** A very simple C program to print one line to the standard out
*/

#include <stdio.h>

int main() {
  printf ("In the beginning...\n");
  return 0;
}
