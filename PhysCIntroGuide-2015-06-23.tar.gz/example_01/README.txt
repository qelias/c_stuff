This file can be built into an executable by using gcc.  For example:

gcc -o in_the_beginning.exe in_the_beginning.c

The executable can then be run by typing

./in_the_beginning.exe
