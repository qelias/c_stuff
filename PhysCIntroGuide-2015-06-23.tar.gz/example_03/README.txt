This file can be built into an executable by using gcc.  For example:

g++ -o pointers.exe pointers.c

The executable can then be run by typing

./pointers.exe
