To re-create the eventgen.dat file:
export CLAB_SUPPORT_DIR=<path to CLAB directory>
make
./pptobbar.exe ../../../data/pptobbar_hepevt.dat 10000

