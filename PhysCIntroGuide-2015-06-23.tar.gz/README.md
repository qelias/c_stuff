C programming for physicists
============================

A short course in ASCII C programming for physicists

Written by W. H. Bell [ http://www.whbell.net/ ]

Description
-----------

This is a short programming course that was originally written in 2007.  The course covers all basic 
aspects of ANSI C through a set of worked examples.  This repository contains the course guide, worked 
examples, problems and solutions.

------------------------------------------------------
