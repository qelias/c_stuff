This file can be built into an executable by using gcc.  For example:

gcc -o stdio_tests.exe stdio_tests.c

The executable can then be run by typing

./stdio_tests.exe
