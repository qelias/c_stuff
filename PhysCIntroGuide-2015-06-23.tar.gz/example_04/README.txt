This file can be built into an executable by using gcc.  For example:

gcc -o command_line.exe command_line.c

The executable can then be run by typing

./command_line.exe [arg1] [arg2] ....

where [argN] is an optional argument 
