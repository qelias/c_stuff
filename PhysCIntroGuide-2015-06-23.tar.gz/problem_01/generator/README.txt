To create the sample.txt file:
  make
  ./generator.exe > sample.txt
