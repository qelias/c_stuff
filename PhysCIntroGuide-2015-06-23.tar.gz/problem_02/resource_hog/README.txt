To build the resource_hog.exe type

make

Then to run resource_hog.exe type

./resource_hog.exe 

The resource hog loops forever.  To kill the process type CTRL-C
