/* 
** A function to interface C with gnuplot.  The string is passed to gnuplot.
*/
void gnuplot(const char *); 
