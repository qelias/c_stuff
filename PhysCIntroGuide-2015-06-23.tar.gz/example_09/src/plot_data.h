/* Included for definition of 'sample' */
include "gen_data.h"

/* A function to plot a data sample with gnuplot */
int plot_data(sample *);
